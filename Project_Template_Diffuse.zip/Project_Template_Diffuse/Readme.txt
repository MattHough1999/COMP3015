Difuse in the vertex shader 
- Using a point light
- low poly mesh set up for torus (16 sides and 16 rings)
- for high poly mesh for torus use (50 sides and 50 rings)
- for teapot, use scenebasic_uniform class and read the comments. You need to comment out any torus calls and just use teapot 
- no need to change vertex or fragment shader. 